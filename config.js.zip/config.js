module.exports = {
  google_api_key: 'AIzaSyChFsFBmHZmdEu20OSV4tKIGs_73gqwkXk',
  consumer_key: 'Jw8JYS9SPtcPLCvBmf5RVL6Na',
  consumer_secret: 'CyicWISFpT6kXbj7gD4WOSN73FXw3sCx7PJZYhIrRIbaqwmSIY',
  access_token: '1127724845750374400-lZ5ePbUK3gcihBKtYooYBkfeDM4y2N',
  access_token_secret: 'TB6iR5ZyrzDIhBW901VWTeOOlIo9pAqM1v3CXX4fVydEv'
}
